---
name: Enhancement request
about: Elastic Agent can't do all the things, but maybe it can do your things.

---

**Describe the enhancement:**

**Describe a specific use case for the enhancement or feature:**

**What is the definition of done?**

<!-- Mandatory
Explain here what are the conditions to validate this change
-->

