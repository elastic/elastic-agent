// Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
// or more contributor license agreements. Licensed under the Elastic License;
// you may not use this file except in compliance with the Elastic License.

package cmd

import (
	"context"
	"fmt"
	"os"
	"time"

	"github.com/elastic/elastic-agent/pkg/control/v2/client"
	"github.com/elastic/elastic-agent/pkg/control/v2/cproto"

	"github.com/spf13/cobra"

	"github.com/elastic/elastic-agent/internal/pkg/cli"
	"github.com/elastic/elastic-agent/internal/pkg/diagnostics"
)

func newDiagnosticsCommand(_ []string, streams *cli.IOStreams) *cobra.Command {
	cmd := &cobra.Command{
		Use:   "diagnostics",
		Short: "Gather diagnostics information from the Elastic Agent and write it to a zip archive",
		Long:  "This command gathers diagnostics information from the Elastic Agent and writes it to a zip archive.",
		Run: func(c *cobra.Command, args []string) {
			if err := diagnosticCmd(streams, c); err != nil {
				fmt.Fprintf(streams.Err, "Error: %v\n%s\n", err, troubleshootMessage())
				os.Exit(1)
			}
		},
	}

	cmd.Flags().StringP("file", "f", "", "name of the output diagnostics zip archive")
	cmd.Flags().BoolP("cpu-profile", "p", false, "wait to collect a CPU profile")

	return cmd
}

func diagnosticCmd(streams *cli.IOStreams, cmd *cobra.Command) error {
	fileName, _ := cmd.Flags().GetString("file")
	if fileName == "" {
		ts := time.Now().UTC()
		fileName = "elastic-agent-diagnostics-" + ts.Format("2006-01-02T15-04-05Z07-00") + ".zip" // RFC3339 format that replaces : with -, so it will work on Windows
	}

	ctx := handleSignal(context.Background())

	daemon := client.New()
	err := daemon.Connect(ctx)
	if err != nil {
		return fmt.Errorf("failed to connect to daemon: %w", err)
	}
	defer daemon.Disconnect()

	fetchCPU, _ := cmd.Flags().GetBool("cpu-profile")

	additionalDiags := []cproto.AdditionalDiagnosticRequest{}
	if fetchCPU {
		// console will just hang while we wait for the CPU profile; print something so user doesn't get confused
		fmt.Fprintf(streams.Out, "Creating diagnostics archive, waiting for CPU profile...\n")
		additionalDiags = []cproto.AdditionalDiagnosticRequest{cproto.AdditionalDiagnosticRequest_CPU}
	}

	agentDiag, err := daemon.DiagnosticAgent(ctx, additionalDiags)
	if err != nil {
		return fmt.Errorf("failed to fetch agent diagnostics: %w", err)
	}

	unitDiags, err := daemon.DiagnosticUnits(ctx)
	if err != nil {
		return fmt.Errorf("failed to fetch unit diagnostics: %w", err)
	}

	compDiags, err := daemon.DiagnosticComponents(ctx, additionalDiags)
	if err != nil {
		return fmt.Errorf("failed to fetch component diagnostics: %w", err)
	}

	f, err := os.Create(fileName)
	if err != nil {
		return fmt.Errorf("error creating .zip file: %w", err)
	}
	defer f.Close()

	if err := diagnostics.ZipArchive(streams.Err, f, agentDiag, unitDiags, compDiags); err != nil {
		return fmt.Errorf("unable to create archive %q: %w", fileName, err)
	}
	fmt.Fprintf(streams.Out, "Created diagnostics archive %q\n", fileName)
	fmt.Fprintln(streams.Out, "***** WARNING *****\nCreated archive may contain plain text credentials.\nEnsure that files in archive are redacted before sharing.\n*******************")
	return nil
}
